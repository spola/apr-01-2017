<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require("Auth_Controller.php");
class Tareas extends Auth_Controller {
 
    public function buscar() {        
        $this->load->model("TareaModel");
        $idPersona = $this->session->userdata("id");
        $tareas = $this->TareaModel->buscar($idPersona);
        
        $this->load->view("layouts/layout_arriba.php", array(
            "active" =>"tareas",
            "isLogged" => true
        ));
        $this->load->view("tareas/listar", array(
            "tareas" => $tareas
        ));
        $this->load->view("layouts/layout_abajo.php");
    }
    
    public function show($id) {
        $this->load->model("TareaModel");
        
        $tarea = $this->TareaModel->getById($id);
        
        
        $this->load->view("tareas/tarea_show", array(
            "tarea"=>$tarea
        ));
    }
}