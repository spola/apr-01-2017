<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ejemplo extends CI_Controller {

    public function index() {
        
        $this->load->view("layouts/layout_arriba.php",array(
            "active" => "ejemplo"
        ));
        //$this->load->view("ejemplo/ejemplo_index");
        $this->load->view("layouts/layout_abajo.php");
        
    }
}