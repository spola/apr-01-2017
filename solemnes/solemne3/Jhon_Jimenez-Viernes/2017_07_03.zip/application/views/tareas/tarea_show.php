

<?php
var_dump($tarea);