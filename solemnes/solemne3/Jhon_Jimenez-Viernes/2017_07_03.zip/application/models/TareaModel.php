<?php
class TareaModel extends CI_Model {

    
    public function buscar($idPersona) {
        
        $tareas = $this->db
            ->select("id, nombre, estado, prioridad")
            ->from("tareas")
            ->where("id_persona", $idPersona)
            ->get();
        return $tareas->result();
    }
    
    public function getById($id) {
        $tarea = $this->db
            ->select("id, nombre, descripcion, inicio, termino, estado, prioridad, id_persona")
            ->from("tareas")
            ->where("id", $id)
            ->get()
            ->row();
        
        return $tarea;
    }
    
}